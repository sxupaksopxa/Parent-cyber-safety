Live demo: https://jolly-flower-05d529203.1.azurestaticapps.net/

# Parent Cyber Safety

A gentle digital tool that helps parents assess and improve their child’s online safety through practical guidance.

## Architecture

- Frontend: React 18 + Vite
- Styling: TailwindCSS
- Assessment Engine: Custom rule-based scoring logic
- Hosting: Azure Static Web Apps
- CI/CD: GitHub Actions
